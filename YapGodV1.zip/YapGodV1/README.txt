This wasn't meant to copy/steal any idea that was probably already made before.
This was just made for the silly n giggles!
I'm not making this open-source now because there's some flaws, and private data hidden in some codes.

Q: Bro how do I use this properly?
A: Play Eminem - Rap God itself

On Spotify you go to: 4:21 then click Yes immediately when Eminem says "Uh"

On YouTube you also go to: 4:21 then click Yes immediately when Eminem says "Uh"

On Apple Music you aswell go to: 4:21 then click Yes immediately when Eminem says "Uh"

Spotify Rap God: https://open.spotify.com/track/6or1bKJiZ06IlK0vFvY75k?si=2b962e9c8c3d483e

YouTube Rap God: https://www.youtube.com/watch?v=XbGs_qK2PQA

Apple Music Rap God: https://music.apple.com/ca/album/rap-god/1440862963?i=1440863086